<?php include_once('../header.php'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="../css/style.css?vs=2">
<link rel="stylesheet" href="../css/responsive.css?vs=1">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<?php 
    include_once("../class/fetch_data.php");
    $completed_projects=new fetch_data();
?>
<section class="team-section">
    <div class="container-fluid text-center">
        <div class="sec-title-two text-center">
            <h2>Upcoming <span>Projects</span></h2>
        </div>
        <div class="row clearfix">
            <!-- Team Block -->
            <?php 
                $sql=$completed_projects->get_upcomming();
                while($row=mysqli_fetch_array($sql))
                    {
            ?>
            <div class="team-block col-md-6 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><img src="../admin/blogs_images/<?= $row['tbumb_image'] ?>" alt=""></figure>
                    </div>
                    <div class="info-box">
                        <h4 class="name"><a href="#"><?= $row['project_name'] ?></a></h4>
                        <a href="../projects.php/<?= $row['url'] ?>" class="theme-btn btn-style-one">View More</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>
<section class="gallery-bottom">
    <div class="container clearfix">
        <div class="sec-title-three float-left">
            <h2>Surround yourself with people <br>who sync with you</h2>
        </div>
        <div class="link-btn float-right">
            <a href="#" class="theme-btn btn-style-two">Book Now</a>
        </div>
    </div>
</section>
<footer class="main-footer">
    <div class="container">
        <div class="footer-area text-center">
            <ul class="footer-menu">
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Completed Projects</a></li>
                <li><a href="">Ongoing Projects</a></li>
                <li><a href="">Upcomming Projects</a></li>
                <li><a href="">Contact Us</a></li>
            </ul>
        </div>            
    </div>
</footer>
<section class="footer-bottom">
    <div class="container">
        <div class="copyright-text text-center">
            Copyright &copy; <a href="#">Reegraaj</a> 2019. All Rights Reserved
        </div>
    </div>
</section>
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>
<script src="../js/jquery.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/owl.js"></script>
<script src="../js/wow.js"></script>
<script src="../js/jquery.countTo.js"></script>
<script src="../js/jquery.countdown.min.js"></script>
<script src="../js/appear.js"></script>
<script src="../js/jquery-ui.js"></script>
<script src="../js/isotope.js"></script>
<script src="../js/bxslider.js"></script>
<script src="../js/validate.js"></script>
<script src="../js/custom.js"></script>
</div>
</body>
</html>