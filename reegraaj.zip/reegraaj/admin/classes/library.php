<?php

define("SMTP_HOST", "email.dorfketal.com"); //Hostname of the mail server
define("SMTP_PORT", 25); //Port of the SMTP like to be 25, 80, 465 or 587
define("SMTP_UNAME", "eeCeeLearn"); //Username for SMTP authentication any valid email created in your domain
define("SMTP_PWORD", "dkc@123"); //Password for SMTP authentication


?>