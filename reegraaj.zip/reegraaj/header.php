<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>REEGRAAJ</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="css/style.css?vs=5">
	<link rel="stylesheet" href="css/responsive.css?vs=1">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">
</head>
<body>   
<div class="boxed_wrapper">
<div class="preloader"></div>
<div class="sdfasd"></div>
<header class="main-header">
    <div class="header-top">
        <div class="container">
            <div class="clearfix">
                <div class="top-left">
                    <ul class="header-info-list">
                        <li><span class="icon fa fa-envelope"></span><strong>Email</strong> reegraajalbani@abc.com</li>
                        <li><span class="icon fa fa-phone"></span><strong>Call</strong> +91 987654321</li>
                    </ul>
                </div>
                <div class="top-right">
                    <!--Social Box-->
                    <ul class="social-box">
                        <li class="share">Connect With Us</li>
                        <li><a href="#"><span class="fab fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fab fa-linkedin"></span></a></li>
                        <li><a href="#"><span class="fab fa-vimeo"></span></a></li>
                        <li><a href="#"><span class="fab fa-google-plus"></span></a></li>
                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="header-upper">
        <div class="container">
            <div class="clearfix">
                <div class="float-left logo-box">
                    <div class="logo"><a href="index.html"><img src="images/RDS.png" alt="" title="" style="max-width: 157px;"></a></div>
                </div>
                <div class="nav-outer clearfix">
                    <nav class="main-menu navbar-expand-md">
                        <div class="navbar-header">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                <li><a href="#">Home</a></li>
                                <li><a href="#">About</a></li>
                                <li class="dropdown"><a href="#">Projects</a>
                                    <ul>
                                        <li><a href="">Ongoing Projects</a></li>
                                        <li><a href="">Upcomming Projects</a></li>
                                        <li><a href="">Completed Projects</a></li>
                                    </ul>
                                </li>
                                <li><a href="">Contact us</a></li>
                            </ul>
                        </div> 
                    </nav> 
                    <div class="button-box">
                        <a href="#" class="theme-btn btn-style-one">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sticky-header stricky">
        <div class="container clearfix">
            <div class="logo float-left">
                <div class="logo"><a href="index.html"><img src="images/RDS.png" alt="" title="" style="max-width: 157px;"></a></div>
            </div>
            <div class="right-col float-right">
                <nav class="main-menu navbar-expand-md">
                        <div class="navbar-header">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                <li><a href="#">Home</a></li>
                                <li><a href="#">About</a></li>
                                <li class="dropdown"><a href="#">Projects</a>
                                    <ul>
                                        <li><a href="">Ongoing Projects</a></li>
                                        <li><a href="">Upcomming Projects</a></li>
                                        <li><a href="">Completed Projects</a></li>
                                    </ul>
                                </li>
                                <li><a href="">Contact us</a></li>
                            </ul>
                        </div> 
                    </nav>
            </div>
        </div>
    </div>
</header>